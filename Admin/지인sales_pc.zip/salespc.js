function clickColor() {
    var List1 = document.getElementsByClassName('List1')[0];

    for (var i = 0; i < List1.length; i++) {
        List1[i].addEventListener('click', function(){
        for (var j = 0; j < List1.length; j++) {
            List1[j].style.Color = "black";
        }
        this.style.backgroundColor = "red";
      })
    }
}



// 메뉴 선택시 색상 변경 및 유지, css랑 같이 사용
const menuWrap = document.querySelector('.menu-wrap'); // ul태그 변수에 담기
function select(ulEl, liEl){  //함수 select 만들기

    Array.from(ulEl.children).forEach(   // ul의 자식 li를 배열로 지정하고 반복하기
        v => v.classList.remove('selected')  // 반복해서 selected라는 클래스를 지우기

    )

    if(liEl) liEl.classList.add('selected'); // liEl라면 selected라는 클래스를 더하기

    } 

menuWrap.addEventListener('click', e => {  //ul 메뉴랩이 클릭되었을때 이벤트 작동
    const selected = e.target;   //클릭된 요소를 변수에 담기
    select(menuWrap, selected); //만들었던 함수 select 적용하기 (선택된 요소만 selected 클래스 더하기)
})

 

